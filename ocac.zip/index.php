<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>OCAC File Upload</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous"><link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css'><link rel="stylesheet" href="./style.css">
</head>
<body>
<form action="upload.php" method="post" enctype="multipart/form-data">
  <center><img src="zimage/logo.png" width="250" height="300"></center>
<div id="FileUpload">
  <div class="wrapper">
    <div class="upload">
    <div class="dropzone">
			<img src="zimage/icon.png" class="upload-icon"  height="50" width="50"/>
			<input type="file" class="upload-input" name="fileToUpload" id="fileToUpload" accept="application/pdf"/>
		</div>    
    </div>
  </div>
</div>
<!-- partial --><center><br>
<input type="submit" class="button button4" value="Upload" name="submit"></center>
</form>
</body>
</html>
